//To run the file on terminal
//Step 1 : tsc BasicsOfts.ts
//Step 2 : node BasicsOfts.js
// 1. Datatypes and Variables
var userName = "John"; // String
var age = 25; // Number
var isStudent = true; // Boolean
var hobbies = ["reading", "gaming"]; // Array
var person = { name: "Alice", age: 30 }; // Object
var id = 123; // Any
var tuple = ["John", 25]; // Tuple
var Color;
(function (Color) {
    Color[Color["Red"] = 0] = "Red";
    Color[Color["Green"] = 1] = "Green";
    Color[Color["Blue"] = 2] = "Blue";
})(Color || (Color = {}));
var c = Color.Green;
console.log("Username:", userName);
console.log("Age:", age);
console.log("Is Student:", isStudent);
console.log("Hobbies:", hobbies);
console.log("Person:", person);
console.log("ID:", id);
console.log("Tuple:", tuple);
console.log("Color Enum Value (Green):", c);
console.log("Color Enum Name:", Color[c]);
// 2. Operators
// Arithmetic Operators
var a = 10;
var b = 3;
console.log(a + b); // Addition: 13
console.log(a - b); // Subtraction: 7
console.log(a * b); // Multiplication: 30
console.log(a / b); // Division: 3.333...
console.log(a % b); // Modulus: 1
console.log(a++); // Increment: 10 (logs 10, then a becomes 11)
console.log(--b); // Decrement: 2 (b becomes 2, then logs 2)
// Comparison Operators
var x = 5;
var y = "5";
console.log(x == Number(y)); // Loose equality: true (compares value)
console.log(x === Number(y)); // Strict equality: false (compares value and type)
console.log(x != Number(y)); // Loose inequality: false
console.log(x !== Number(y)); // Strict inequality: true
console.log(x > 4); // Greater than: true
console.log(x < 6); // Less than: true
console.log(x >= 5); // Greater than or equal: true
console.log(x <= 4); // Less than or equal: false
// Logical Operators
var isAdult = true;
var hasID = false;
console.log(isAdult && hasID); // AND: false (both must be true)
console.log(isAdult || hasID); // OR: true (at least one is true)
console.log(!isAdult); // NOT: false (inverts the value)
// Bitwise Operators
var p = 5; // Binary: 0101
var q = 3; // Binary: 0011
console.log(p & q); // AND: 1 (Binary: 0001)
console.log(p | q); // OR: 7 (Binary: 0111)
console.log(p ^ q); // XOR: 6 (Binary: 0110)
console.log(~p); // NOT: -6 (Inverts bits, 2's complement)
console.log(p << 1); // Left shift: 10 (Binary: 1010)
console.log(p >> 1); // Right shift: 2 (Binary: 0010)
console.log(p >>> 1); // Unsigned right shift: 2 (Binary: 0010)
// Assignment Operators
var num = 10;
num = 20; // Assignment: 20
num += 5; // Add and assign: 25
num -= 10; // Subtract and assign: 15
num *= 2; // Multiply and assign: 30
num /= 3; // Divide and assign: 10
console.log(num); // 10
// Ternary Operator
var stat = age >= 18 ? "Adult" : "Minor";
console.log(stat); // Adult
// 3. Decision Making and Loops
var score = 85;
if (score >= 90) {
    console.log("A");
}
else if (score >= 80) {
    console.log("B");
}
else {
    console.log("C");
}
var day = 2;
switch (day) {
    case 1:
        console.log("Monday");
        break;
    case 2:
        console.log("Tuesday");
        break;
    default: console.log("Invalid");
}
for (var i_1 = 0; i_1 < 5; i_1++) {
    console.log(i_1); // 0, 1, 2, 3, 4
}
var i = 0;
while (i < 5) {
    console.log(i);
    i++;
}
var j = 0;
do {
    console.log(j);
    j++;
} while (j < 5);
function add(a, b) {
    return a + b;
}
console.log(add(5, 3)); // 8
var multiply = function (a, b) {
    return a * b;
};
console.log(multiply(4, 2)); // 8
function greet(name, greeting) {
    if (greeting === void 0) { greeting = "Hello"; }
    return "".concat(greeting, ", ").concat(name, "!");
}
console.log(greet("John")); // Hello, John!
console.log(greet("John", "Hi")); // Hi, John!
