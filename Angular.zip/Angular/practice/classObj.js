//To run the file on terminal
//Step 1 : tsc classObj.ts
//Step 2 : node classObj.js
var __extends = (this && this.__extends) || (function () {
    var extendStatics = function (d, b) {
        extendStatics = Object.setPrototypeOf ||
            ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
            function (d, b) { for (var p in b) if (Object.prototype.hasOwnProperty.call(b, p)) d[p] = b[p]; };
        return extendStatics(d, b);
    };
    return function (d, b) {
        if (typeof b !== "function" && b !== null)
            throw new TypeError("Class extends value " + String(b) + " is not a constructor or null");
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Person = /** @class */ (function () {
    function Person(name, age) {
        this.name = name;
        this.age = age;
    }
    Person.prototype.greet = function () {
        return "Holaa, I'm ".concat(this.name, ", and I'm ").concat(this.age, " years old.");
    };
    return Person;
}());
var person1 = new Person("Prii", 20);
console.log(person1.greet()); // Holaa, I'm Prii, and I'm 20 years old.
var Student = /** @class */ (function (_super) {
    __extends(Student, _super);
    function Student(name, age, grade) {
        var _this = _super.call(this, name, age) || this;
        _this.grade = grade;
        return _this;
    }
    Student.prototype.study = function () {
        return "".concat(this.name, " is eating her favourite ").concat(this.grade, ".");
    };
    return Student;
}(Person));
var student1 = new Student("Prii", 20, "pizza");
console.log(student1.greet()); // Hi, I'm Priya, and I'm 20 years old.
console.log(student1.study()); // Priya is eating her favourite pizza.
var user = { id: 1, name: "Priyoo" };
console.log(user.id);
console.log(user.name);
