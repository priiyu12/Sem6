var m1:string = "ABC";
console.log(m1);
