var x: number = 10, y = 20;

if (x < y) 
{
    console.log('x is less than y');
} 


/*let let x: number = 10, y = 20;

if (x > y) 
{
    console.log('x is greater than y.');
} 
else
{
    console.log('x is less than or equal to y.'); //This will be executed
}


 let x: number = 10, y = 20;

if (x > y) 
{
    console.log('x is greater than y.');
} 
else if (x < y)
{
    console.log('x is less than y.'); //This will be executed
}
else if (x == y) 
{
    console.log('x is equal to y');
}*/