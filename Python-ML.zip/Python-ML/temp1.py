#SVC : Non-Linear Data
#1. Import Required Libraries
import numpy as np
import matplotlib.pyplot as plt
import pandas as pd
from sklearn.preprocessing import StandardScaler
from sklearn.svm import SVC
from sklearn.model_selection import train_test_split
from sklearn import metrics

#2. Load the Dataset
data = pd.read_csv("Social_Network_Ads.csv")
print(data.head()) # Corrected from head() to data.head()
print(data.shape)

#3. Split Data into Input (X) and Output (Y)
x = data.iloc[:, [2, 3]] # Age and Salary as input variables
y = data.iloc[:, 4] # Purchased as output variable

#4. Split Dataset into Train and Test Sets
X_train, X_test, Y_train, Y_test = train_test_split(x, y, test_size=0.20, random_state=0)
print(X_train.shape, X_test.shape, Y_train.shape, Y_test.shape)

# Scale the features
scaler = StandardScaler()
X_train = scaler.fit_transform(X_train)
X_test = scaler.transform(X_test)

# Train the classifier with a polynomial kernel
classifier = SVC(kernel='poly')
classifier.fit(X_train, Y_train)

# Predict the test set results
Y_pred = classifier.predict(X_test)
print(Y_pred)

# Calculate and print accuracy score
print("Accuracy Score: With polynomial kernel")
print(metrics.accuracy_score(Y_test, Y_pred))

# Visualize the decision boundary using a contour plot
x_min, x_max = X_test[:, 0].min() - 1, X_test[:, 0].max() + 1
y_min, y_max = X_test[:, 1].min() - 1, X_test[:, 1].max() + 1
xx, yy = np.meshgrid(np.arange(x_min, x_max, 0.1), np.arange(y_min, y_max, 0.1))

# Predict on the grid
Z = classifier.predict(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Plot decision boundary and the test data points
plt.contourf(xx, yy, Z, alpha=0.75, cmap='tab20')
plt.scatter(X_test[:, 0], X_test[:, 1], c=Y_test, edgecolors='k',marker='o', cmap='tab10')
plt.title("SVM with Polynomial Kernel")
plt.xlabel("Age")
plt.ylabel("Salary")
plt.show()