# K-MEAN CLUSTERING
import numpy as np #create and manipulate arrays
import matplotlib.pyplot as plt #plotting graphs
from sklearn.cluster import KMeans #perform K-Means Clustering

data = np.array([
    [185, 72],
    [170, 56],
    [168, 60],
    [179, 68],
    [182, 72],
    [188, 77],
    [180, 71],
    [180, 70]
])

kmeans = KMeans(n_clusters=2, random_state=42, n_init=10)
kmeans.fit(data)

labels = kmeans.labels_
centroids = kmeans.cluster_centroids_

print("Cluster Labels : ", labels)

plt.figure(figsize(6,8))
plt.scatter(data[:,0], data[:,1], c="labels", marker="o", label="Data Points")
plt.scatter(centroids[:,0], centroids[:,1], c="red", marker="X", s=200, label="Centroids")

plt.Xlabel("Height")
plt.Ylabel("Weight")
plt.title("K-Mean Cluster (K=2)")
plt.legend()
plt.grid(True)
plt.show()

