import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression

# Step 1: Prepare Data
X = np.array([1.5, 3.0, 4.5, 6.0, 7.5]).reshape(-1, 1)  # Study hours (Feature)
y = np.array([50, 60, 70, 80, 90])  # Exam Scores (Target)

# Step 2: Train the Model
model = LinearRegression()
model.fit(X, y)

# Step 3: Make a Prediction
new_study_hours = np.array([[5.0]])  # Predict for 5 hours of study
predicted_score = model.predict(new_study_hours)
print(f"Predicted Score for 5 hours of study: {predicted_score[0]:.2f}")

# Step 4: Plot the Regression Line
plt.figure(figsize=(8, 5))  # Set figure size
plt.scatter(X, y, color='blue', label='Actual Data')  # Scatter plot of actual data
plt.plot(X, model.predict(X), color='red', linestyle='dashed', label='Regression Line')  # Regression Line
plt.scatter(new_study_hours, predicted_score, color='green', marker='o', s=100, label=f'Predicted: {predicted_score[0]:.2f}')  # Prediction point

# Step 5: Customize Plot
plt.xlabel("Study Hours")
plt.ylabel("Exam Score")
plt.title("Simple Linear Regression: Study Hours vs Exam Score")
plt.legend()
plt.grid(True)
plt.show()
