import pandas as pd
import numpy as np
import matplotlib.pyplot as plt
from sklearn.linear_model import LinearRegression
from sklearn.model_selection import train_test_split

# Step 1: Load Data from CSV
df = pd.read_csv("study_exam.csv")  # Load dataset

# Step 2: Prepare Features and Target Variable
X = df[['Study Hours']].values  # Independent Variable (Study Hours) - Convert to NumPy array
y = df['Exam Score'].values  # Dependent Variable (Exam Score)

# Step 3: Split into Training and Testing Data (80% Train, 20% Test)
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2, random_state=0)

# Step 4: Train the Model
model = LinearRegression()
model.fit(X_train, y_train)  # Train model on training data

# Step 5: Make Predictions
predicted_scores = model.predict(X_test)

# Step 6: Visualizing Regression Line
plt.figure(figsize=(8, 5))
plt.scatter(X, y, color='blue', label="Actual Data")  # Scatter plot for actual data
plt.plot(X_train, model.predict(X_train), color='red', linestyle='dashed', label="Regression Line")  # Regression line

# Step 7: Customize Plot
plt.xlabel("Study Hours")
plt.ylabel("Exam Score")
plt.title("Simple Linear Regression: Study Hours vs Exam Score")
plt.legend()
plt.grid(True)
plt.show()

# Step 8: Predict the Exam Score for 7.5 Study Hours
new_study_hours = np.array([[7.5]])  # Ensure it's 2D
predicted_score = model.predict(new_study_hours)

# Print predicted score
print(f"Predicted Exam Score for 7.5 Study Hours: {predicted_score[0]:.2f}")
