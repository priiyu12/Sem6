import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.datasets import make_classification
# Create synthetic data (two classes)
X, y =make_classification(
	n_samples=50, n_features=2, n_informative=2,
	n_redundant=0,random_state=1,class_sep=1.5
)

# Train a linear SVM classifier
classifier = SVC(kernel='linear', C=1.0) # C is the regularization parameter
classifier.fit(X, y)

# Plot the data and decision boundary
plt.scatter(X[:, 0],X[:, 1],c=y,cmap='viridis')

# Get the separating hyperplane
w = classifier.coef_[0]
b = classifier.intercept_[0]
xx = np.linspace(X[:, 0].min() - 1, X[:, 0].max() + 1)
yy = (-b - w[0] * xx) / w[1]

plt.plot(xx,yy, "k-") # Plot the hyperplane
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.title("Linear SVM Classification")
plt.show()
# Example of making predictions
new_data = np.array([[2, 1]]) # Example data point
prediction = clf.predict(new_data)
print(f"Prediction for {new_data}: {prediction}")