# NON- LINEAR SVM
import numpy as np
import matplotlib.pyplot as plt
from sklearn.svm import SVC
from sklearn.datasets import make_circles

# Create non-linearly separable data
X, y = make_circles(
    n_samples=100, factor=0.5, 
    noise=0.05, random_state=1
)











# Train an SVM with a radial basis function (RBF) kernel
classifier = SVC(kernel='rbf', C=1.0, gamma='scale') # gamma controls the width of the RBF kernel
classifier.fit(X, y)

# Create a meshgrid to plot the decision boundary
x_min,x_max=X[:,0].min()-1,X[:,0].max()+1
y_min,y_max=X[:,1].min()-1,X[:,1].max()+1
xx, yy = np.meshgrid(np.linspace(x_min,x_max, 100),np.linspace(y_min,y_max, 100))

Z = classifier.decision_function(np.c_[xx.ravel(), yy.ravel()])
Z = Z.reshape(xx.shape)

# Plot the data and decision boundary
plt.contourf(xx, yy, Z, levels=np.linspace(Z.min(), Z.max(), 7), alpha=0.3, cmap='coolwarm')
plt.scatter(X[:, 0], X[:, 1], c=y, cmap='viridis')

#Filled contour
plt.xlabel("Feature 1")
plt.ylabel("Feature 2")
plt.title("Non-Linear SVM (RBF Kernel)")
plt.show()